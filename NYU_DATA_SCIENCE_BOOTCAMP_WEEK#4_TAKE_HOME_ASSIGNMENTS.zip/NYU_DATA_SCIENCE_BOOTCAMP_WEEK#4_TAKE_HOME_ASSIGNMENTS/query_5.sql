# QUERY 5

SELECT MAX(Revenue) AS Most_Revenue, MIN(Revenue) AS Least_Revenue
FROM Sales;