# QUERY 1

SELECT COUNT(Order_id) AS Total_Orders
FROM Sales
WHERE Date = '2023-03-18';