CREATE TABLE CUSTOMERS(
     customer_id VARCHAR(50), 
     first_name VARCHAR(50), 
     last_name VARCHAR(50),
     Address VARCHAR(50)
);

INSERT INTO CUSTOMERS (Customer_id, First_name, Last_name, Address) VALUES
(1, 'John', 'Doe', '123 Elm St, Cityville'),
(2, 'Jane', 'Smith', '456 Oak St, Townsville'),
(3, 'Alice', 'Brown', '789 Pine St, Villagetown'),
(4, 'Bob', 'White', '101 Maple St, Hamlet'),
(101, 'Widget A', 20.00, 'Electronics'),
(102, 'Widget B', 25.00, 'Home Goods'),
(103, 'Widget C', 25.00, 'Toys'),
(104, 'Widget D', 20.00, 'Sports'),
(105, 'Widget E', 15.00, 'Kitchen'),
(106, 'Widget F', 30.00, 'Outdoor');
